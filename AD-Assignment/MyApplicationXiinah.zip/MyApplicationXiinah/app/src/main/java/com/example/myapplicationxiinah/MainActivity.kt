package com.example.myapplicationxiinah

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    private lateinit var countTextView: TextView
    private lateinit var incrementButton: Button
    private lateinit var decrementButton: Button
    private lateinit var resetButton: Button

    private var count = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        countTextView = findViewById(R.id.countTextView)
        incrementButton = findViewById(R.id.incrementButton)
        decrementButton = findViewById(R.id.decrementButton)
        resetButton = findViewById(R.id.resetButton)

        incrementButton.setOnClickListener { onIncrementClick() }
        decrementButton.setOnClickListener { onDecrementClick() }
        resetButton.setOnClickListener { onResetClick() }
    }

    private fun onIncrementClick() {
        val previousCount = count
        count++
        updateCountTextView()
        showToast("Increment: $previousCount -> $count")
    }

    private fun onDecrementClick() {
        val previousCount = count
        count--
        updateCountTextView()
        showToast("Decrement: $previousCount -> $count")
    }

    private fun onResetClick() {
        val previousCount = count
        count = 0
        updateCountTextView()
        showToast("Reset: $previousCount -> $count")
    }

    private fun updateCountTextView() {
        countTextView.text = count.toString()
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
